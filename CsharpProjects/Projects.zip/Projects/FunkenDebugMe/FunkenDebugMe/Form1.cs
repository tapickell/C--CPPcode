﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FunkenDebugMe
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int number = 15;
            number = number + 10;
            number = 36 * 15;
            number = 12 - (42 / 7);
            number += 10;
            number *= 3;
            number = 71 / 3;

            int count = 0;
            count++;
            count--;
            string result = "hey";
            result += "buddy" + result;
            MessageBox.Show(result);
            result = "the value is: " + count;
            result = "";
            bool yesNo = false;
            bool anotherBool = true;
            yesNo = !anotherBool;

            for (int i = 0; i < number; i++)
            {
                MessageBox.Show("loop " + i);
            }
        }
    }
}
