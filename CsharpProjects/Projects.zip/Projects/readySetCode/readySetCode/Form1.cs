﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace readySetCode
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // this is a method DUH
            string name = "Todd";
            int x = 3;
            x *= 17;
            double d = Math.PI / 2;
            MessageBox.Show("name is " + name + "\nx is " + x + "\nd is " + d);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int x = 5;
            if (x == 10)
            {
                MessageBox.Show("x must be 10");
            }
            else
            {
                MessageBox.Show("x must not be 10");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int someValue = 4;
            string name = "stupid";

            if ((someValue == 3) && (name == "Joe"))
            {
                MessageBox.Show("x is " + someValue + " name is " + name);
            }
            MessageBox.Show("This is the else line " + someValue + " " + name);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int count = 0;

            while (count < 10)
            {
                count++;
            }

            for (int i = 0; i < 5; i++)
            {
                count--;
            }

            MessageBox.Show("The answer is " + count);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int count = 5;
            while (count >0)
            {
                count *= 3;
                count *= -1;
                MessageBox.Show("count: " + count);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int i = 0;
            int count = 2;
            while (i == 0)
            {
                count *= 3;
                count *= -1;
                MessageBox.Show("count: " + count);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int j = 2;
            for (int i = 1; i < 100; i = 1 * 2)
            {
                MessageBox.Show("i = " + i);
                j = j - 1;
                while (j < 25)
                {
                    j = j + 5;
                    MessageBox.Show("j = " + j);
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            while (true)
            {
                int i = 1;
                MessageBox.Show("i = " + i);
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            int p = 2;
            for (int q = 2; q < 32; q = q *2)
            {
                while (p < q)
                {
                    p *= 2;
                    MessageBox.Show("p = " + p);
                }
                q = p - q;
                MessageBox.Show("q = " + q);
            }
        }
    }
}
