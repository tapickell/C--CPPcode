/* ***************************************************************************

Programmer: Todd Pickell

Filename: MidtermProject.cpp

Requirements: None

Includes: 
#include "stdafx.h"
#include <iostream>
#include "Game.h"

Course: Programming II

Date: 4/9/12

Assignment: C++ Programming MidTerm Project

Description: MidTerm Project Sub Hunter game

************************************************************************* */
// SubHunter.cpp : main project file.
//  SubHunter
//
//  Created by Todd Pickell on 4/9/12.
//  Copyright (c) 2012 Columbia College. All rights reserved.
//
//  this program worked a lot better b4 redoing it in visual studio
//  



#include "stdafx.h"
#include <iostream>
#include "Game.h"

using namespace System;
using namespace std;

int main(array<System::String ^> ^args)
{
	Game newGame = Game();
    //std::cout << "Hello from main\n";
	system("Pause");
    return 0;
}
