//
//  main.cpp
//  moredice
//
//  Created by Todd Pickell on 4/4/12.
//  Copyright (c) 2012 Columbia College. All rights reserved.
//
//  Includes: <iostream> "Game.h"
//
//  Course: CISS 242A Programming II
//
//  Description:
//  Main function for Dice Rolling program
//
//***************************************************************************

#include <iostream>
#include "Game.h"

int main (int argc, const char * argv[])
{
    Game myGame; // creates an instance of Game
    system("PAUSE"); // pauses output to allow user to view data
    return 0;
}

